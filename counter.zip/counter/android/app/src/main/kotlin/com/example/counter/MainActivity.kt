package com.example.counter

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
